import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

import javax.swing.*;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

@SuppressWarnings("serial")
public class ModelInfo extends JPanel implements ActionListener {
	JFrame f;
	JLabel l1;
	JPanel p1, p2;
	JButton newLog, next, back;
	JRadioButton rButton1;
	ButtonGroup group = new ButtonGroup();
	Font font;
	Dimension buttonDimension;
	static String modelNumber;
	String BitLog, newBitLog, database, bitlogs, strQuery;
	String strQuery1;
	Fillo fillo;
	Connection connection, connection2;
	Recordset recordset;;

	@SuppressWarnings("static-access")
	public ModelInfo(String modelNumber) throws FilloException {

		database = "H:\\My_Documents\\Projects\\CIRCM_Data_Management_System\\src\\Models.xlsx";
		bitlogs = "H:\\My_Documents\\Projects\\CIRCM_Data_Management_System\\BitLogs";
		this.modelNumber = modelNumber;
		f = new JFrame();
		setLayout(new GridLayout(3, 1));
		fillo = new Fillo();
		BitLog = "Could not find BitLog";

		setUpGUI();

	}

	public void setUpGUI() throws FilloException {
		l1 = new JLabel("Pointer/Tracker: " + modelNumber);
		p1 = new JPanel();
		p2 = new JPanel();
		newLog = new JButton("New Log");
		next = new JButton("Next");
		back = new JButton("Back");
		rButton1 = new JRadioButton(getBitlog());
		buttonDimension = new Dimension(75, 20);
		font = new Font("Calibri", Font.BOLD, 18);

		l1.setFont(font);
		l1.setHorizontalAlignment(SwingConstants.CENTER);
		next.setEnabled(false);

		rButton1.addActionListener(this);
		newLog.addActionListener(this);
		next.addActionListener(this);
		back.addActionListener(this);

		newLog.setPreferredSize(buttonDimension);
		next.setPreferredSize(buttonDimension);
		back.setPreferredSize(buttonDimension);

		// p1.add(BitLogs);
		p1.add(rButton1);
		p1.setSize(getMaximumSize());

		p2.add(back);
		p2.add(newLog);
		p2.add(next);

		add(l1);
		add(p1);
		add(p2);

		f.add(this);

		f.setTitle("CIRCM Data Management");
		f.setSize(450, 125);
		f.setVisible(true);
		f.setLocationRelativeTo(null);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public String getBitlog() throws FilloException {

		connection = fillo.getConnection(database);
		strQuery = "SELECT BitLog1 from Sheet1 where Models=" + modelNumber;
		recordset = connection.executeQuery(strQuery);

		while (recordset.next()) {
			BitLog = recordset.getField("BitLog1");
		}

		recordset.close();
		connection.close();
		return BitLog;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == back) {
			back();
		} else if (e.getSource() == rButton1) {
			next.setEnabled(true);
		} else if (e.getSource() == next) {
			displayInfo();
		} else if (e.getSource() == newLog) {
			try {
				createNewLog();
			} catch (FilloException | IOException e1) {
				e1.printStackTrace();
			}
		}
	}

	public void back() {
		try {
			GUI.main(null);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		f.dispose();
	}

	public void createNewLog() throws FilloException, IOException {

		JFileChooser j = new JFileChooser();
		j.showOpenDialog(null);
		newBitLog = (j.getSelectedFile().getPath());

		Path source = FileSystems.getDefault().getPath(newBitLog);
		Path newdir = FileSystems.getDefault().getPath(bitlogs);

		Files.move(source, newdir.resolve(source.getFileName()),
				StandardCopyOption.REPLACE_EXISTING);

		newBitLog = newdir.resolve(source.getFileName()).toString();

		connection2 = fillo.getConnection(database);
		strQuery1 = "UPDATE Sheet1 SET BitLog1 = '" + newBitLog
				+ "' WHERE Models = " + modelNumber;
		connection2.executeUpdate(strQuery1);
		connection2.close();

		rButton1.setText(getBitlog());

	}

	public void displayInfo() {
		try {
			DisplayInfo di = new DisplayInfo(BitLog);
		} catch (FilloException e) {
			JOptionPane j = new JOptionPane();
			JOptionPane
					.showMessageDialog(new JFrame(), "Error: File not found");
			e.printStackTrace();
		}
		f.dispose();
	}

}
