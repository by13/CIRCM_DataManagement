package BITFaultAnalysisTool;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

import javax.swing.*;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;


public class BitLogs {

	String BitLog, newBitLog, database, bitlogs, strQuery;
	String strQuery1;
	Fillo fillo;
	Connection connection, connection2;
	Recordset recordset;;

	public BitLogs()  {

		database = SerialNumbers.file;
		bitlogs = "\\\\des.grplnk.net\\svr2\\EDI\\Project\\DircmENG\\SPT\\CIRCM\\Users\\Bradley\\BITFaultAnalysisTool\\Bitlogs";
		fillo = new Fillo();
		BitLog = "Could not find BitLog";

	}

	public String getBitlog(String serialNumber) throws FilloException {

		connection = fillo.getConnection(database);
		strQuery = "SELECT BitLog1 from Sheet1 where SerialNumber=" + serialNumber;
		recordset = connection.executeQuery(strQuery);

		while (recordset.next()) {
			BitLog = recordset.getField("BitLog1");
		}

		recordset.close();
		connection.close();
		return BitLog;
	}
	
	public void createNewLog(String serialNumber) throws FilloException, IOException {

		JFileChooser j = new JFileChooser();
		j.showOpenDialog(null);
		newBitLog = (j.getSelectedFile().getPath());

		Path source = FileSystems.getDefault().getPath(newBitLog);
		Path newdir = FileSystems.getDefault().getPath(bitlogs);

		Files.move(source, newdir.resolve(source.getFileName()),
				StandardCopyOption.REPLACE_EXISTING);

		newBitLog = newdir.resolve(source.getFileName()).toString();

		connection2 = fillo.getConnection(database);
		strQuery1 = "UPDATE Sheet1 SET BitLog1 = '" + newBitLog
				+ "' WHERE serialNumber = " + serialNumber;
		connection2.executeUpdate(strQuery1);
		connection2.close();

	}

}
