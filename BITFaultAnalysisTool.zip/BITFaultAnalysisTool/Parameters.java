package BITFaultAnalysisTool;

import java.io.PrintStream;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

public class Parameters {
	Fillo f;
	static ArrayList<String> input;
	JFrame error;
	String file;
	String strQuery1, strQuery2, strQuery3;
	PrintStream o;
	Connection c;
	Recordset recordset;
	int ETI;

	public Parameters() {
		f = new Fillo();
		input = new ArrayList<String>();
		error = new JFrame();
		file = "\\\\des.grplnk.net\\svr2\\EDI\\Project\\DircmENG\\SPT\\CIRCM\\Users\\Bradley\\BITFaultAnalysisTool\\BitLogFormat.xlsx";
		strQuery1 = "SELECT * FROM Sheet1";
		o = System.out;

	}

	public void initialise() throws FilloException {
		input.clear();
		// Connect File
		try {
			c = f.getConnection(file);
		} catch (FilloException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(error,
					"Error: Could not load Parameters");
		}

		// Execute query and Put values into record set
		try {
			recordset = c.executeQuery(strQuery1);
		} catch (FilloException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(error,
					"Error: Could not Execute Query");
		}

		ETI = 0;

		setValues();
	}

	public void setValues() throws FilloException {

		input.addAll(recordset.getFieldNames());

		recordset.close();
		c.close();

	}

	public ArrayList<String> getParameters() {
		return input;
	}

}
