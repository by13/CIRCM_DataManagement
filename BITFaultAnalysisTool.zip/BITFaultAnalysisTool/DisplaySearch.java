package BITFaultAnalysisTool;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.swing.*;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

@SuppressWarnings("serial")
public class DisplaySearch extends JFrame implements ActionListener {

	JPanel p1, p2, p3;
	JLabel l1, l2, l3;
	JButton exit, export, back, forwards, backwards;
	Font font, font1;
	ArrayList<String> listP1;
	ArrayList<String> listP2;
	Dimension buttonDimension, panelDimension;
	String PT, param1, param2;
	double paramValue1, paramValue2;
	PrintStream o;
	int index;

	public DisplaySearch(String PT, double paramValue1, double paramValue2,
			String param1, String param2) throws FilloException {

		setLayout(new BoxLayout(this.getContentPane(), BoxLayout.PAGE_AXIS));

		o = System.out;
		this.PT = PT;
		this.paramValue1 = paramValue1;
		this.paramValue2 = paramValue2;
		this.param1 = param1;
		this.param2 = param2;
		index = 0;
		listP1 = new ArrayList<String>();
		listP2 = new ArrayList<String>();

		initUI();
		loadValues();

		setTitle("CIRCM Data Management System");
		setVisible(true);
		setSize(400, 140);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	public void initUI() {
		buttonDimension = new Dimension(75, 20);
		panelDimension = new Dimension(300, 20);

		p1 = new JPanel();
		p2 = new JPanel();
		p3 = new JPanel();

		l1 = new JLabel("Pointer/Tracker: " + PT);
		l2 = new JLabel(param2 + " = " + paramValue1);
		l3 = new JLabel(param1 + " = ");
		exit = new JButton("Exit");
		export = new JButton("Export");
		back = new JButton("Back");
		forwards = new JButton("->");
		backwards = new JButton("<-");

		font = new Font("Calibri", Font.BOLD, 18);
		font1 = new Font("Calibri", Font.PLAIN, 15);

		exit.addActionListener(this);
		export.addActionListener(this);
		back.addActionListener(this);
		forwards.addActionListener(this);
		backwards.addActionListener(this);

		l1.setFont(font);
		l1.setAlignmentX(Component.CENTER_ALIGNMENT);
		l2.setFont(font1);
		l3.setFont(font1);

		exit.setPreferredSize(buttonDimension);
		export.setPreferredSize(buttonDimension);
		back.setPreferredSize(buttonDimension);
		forwards.setPreferredSize(new Dimension(buttonDimension));
		backwards.setPreferredSize(new Dimension(buttonDimension));

		p1.setPreferredSize(panelDimension);
		p2.setPreferredSize(panelDimension);
		p3.setPreferredSize(panelDimension);

		p1.add(l2);
		p1.add(new JLabel("     "));
		p1.add(l3);

		p2.add(backwards);
		p2.add(forwards);

		p3.add(back);
		p3.add(export);
		p3.add(exit);

		add(l1);
		add(p1);
		add(p2);
		add(p3);

	}

	@SuppressWarnings("static-access")
	public void loadValues() throws FilloException {
		SerialNumbers sn = new SerialNumbers();
		Fillo fillo = new Fillo();
		Connection connection = fillo.getConnection(sn.file);
		String strQuery1 = "Select BitLog1 from Sheet1 where SerialNumber = "
				+ PT;
		String BITLogFile = null;
		Recordset recordset = connection.executeQuery(strQuery1);

		while (recordset.next()) {
			BITLogFile = recordset.getField("BitLog1");
		}

		recordset.close();
		connection.close();

		connection = fillo.getConnection(BITLogFile);
		String strQuery2 = "Select * from Sheet1 where " + param2 + " > "
				+ paramValue1 + " and " + param2 + " < " + paramValue2;
		try {
			recordset = connection.executeQuery(strQuery2);
		} catch (FilloException e) {
			JOptionPane.showMessageDialog(new JFrame(), "Error: No Data Found");
			e.printStackTrace();
		}
		while (recordset.next()) {
			listP1.add(recordset.getField(param1));
			listP2.add(recordset.getField(param2));
		}
		l2.setText(param2 + " = " + listP2.get(0));
		l3.setText(param1 + " = " + listP1.get(0));

	}

	public void exportData() throws IOException {
		PrintWriter writer = new PrintWriter("outputS.txt", "UTF-8");
		for (int i = 0; i < listP1.size(); i++) {
			writer.println(param2 + " = " + listP2.get(i) + "    " + param1
					+ " = " + listP1.get(i));
		}
		writer.close();
		Desktop desktop = Desktop.getDesktop();
		desktop.open(new File(
				"\\\\des.grplnk.net\\svr2\\EDI\\Project\\DircmENG\\SPT\\CIRCM\\Users\\Bradley\\BITFaultAnalysisTool\\outputS.txt"));
	}

	public void moveForwards() {
		if (index < listP1.size() - 1) {
			forwards.setEnabled(true);
			backwards.setEnabled(true);
			index++;
			l2.setText(param2 + " = " + listP2.get(index));
			l3.setText(param1 + " = " + listP1.get(index));
		} else {
			forwards.setEnabled(false);
			backwards.setEnabled(true);
		}
	}

	public void moveBackwards() {
		if (index == 0) {
			backwards.setEnabled(false);
			forwards.setEnabled(true);
		} else {
			backwards.setEnabled(true);
			forwards.setEnabled(true);
			index--;
			l2.setText(param2 + " = " + listP2.get(index));
			l3.setText(param1 + " = " + listP1.get(index));
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == back) {
			try {
				@SuppressWarnings("unused")
				ChooseSearchParameters csp = new ChooseSearchParameters(PT);
				this.dispose();
			} catch (FilloException e1) {
				e1.printStackTrace();
			}
		} else if (e.getSource() == exit) {
			this.dispose();
		} else if (e.getSource() == export) {
			try {
				exportData();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} else if (e.getSource() == forwards) {
			moveForwards();
		} else if (e.getSource() == backwards) {
			moveBackwards();
		}
	}
}
