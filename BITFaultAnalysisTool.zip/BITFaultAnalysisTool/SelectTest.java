package BITFaultAnalysisTool;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

@SuppressWarnings("serial")
public class SelectTest extends JFrame implements ActionListener {

	JPanel p1, p2, p3;
	JLabel l1;
	JComboBox<String> cb;
	ArrayList<String> testNames;
	JButton next, back;
	Font font;
	Dimension buttonDimension, panelDimension;

	public SelectTest() throws FilloException {

		setLayout(new BoxLayout(this.getContentPane(), BoxLayout.PAGE_AXIS));
		initUI();
		setTitle("CIRCM Data Management System");
		setVisible(true);
		setSize(400, 125);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fillComboBox(getTestNames());
	}

	public void initUI() {
		buttonDimension = new Dimension(75, 20);
		panelDimension = new Dimension(300, 20);

		p1 = new JPanel();
		p2 = new JPanel();
		l1 = new JLabel("Select Test");
		cb = new JComboBox<String>();
		testNames = new ArrayList<String>();
		next = new JButton("Next");
		back = new JButton("Back");
		font = new Font("Calibri", Font.BOLD, 18);

		next.addActionListener(this);
		back.addActionListener(this);
		cb.addActionListener(this);

		next.setEnabled(false);
		back.setEnabled(false);

		l1.setFont(font);
		next.setPreferredSize(buttonDimension);
		back.setPreferredSize(buttonDimension);
	
		p1.setPreferredSize(panelDimension);
		p2.setPreferredSize(panelDimension);

		p1.add(cb);

		p2.add(back);
		p2.add(next);

		l1.setAlignmentX(Component.CENTER_ALIGNMENT);

		add(l1);
		add(p1);
		add(p2);
	}
	
	private ArrayList<String> getTestNames() throws FilloException {
		Fillo fillo = new Fillo();
		Connection connection;
		Recordset recordset;
		String database = "\\\\des.grplnk.net\\svr2\\EDI\\Project\\DircmENG\\SPT\\CIRCM\\Users\\Bradley\\BITFaultAnalysisTool\\TestNames.xlsx";
		
		connection = fillo.getConnection(database);
		String strQuery = "SELECT * from Sheet1";
		recordset = connection.executeQuery(strQuery);

		while (recordset.next()) {
			testNames.add(recordset.getField("TestName"));
		}

		recordset.close();
		connection.close();
		return testNames;
	}

	public void fillComboBox(ArrayList<String> input) {
		cb.removeAllItems();
		for (String i : input) {
			cb.addItem(i);
		}
	}

	public void comboBoxUpdate() {
		next.setEnabled(true);
		back.setEnabled(true);
	}

	public void back() {
		try {
			HomePage.main(null);
		} catch (FilloException e) {
			e.printStackTrace();
		}
		this.dispose();
	}

	@SuppressWarnings("unused")
	public void next() throws FilloException {
		CountOccurences co = new CountOccurences(cb.getSelectedItem().toString());
		this.dispose();
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == next) {
			try {
				next();
			} catch (FilloException e1) {
				e1.printStackTrace();
			}
		} else if (e.getSource() == back) {
			back();
		} else if (e.getSource() == cb) {
			comboBoxUpdate();

		}
	}
}
