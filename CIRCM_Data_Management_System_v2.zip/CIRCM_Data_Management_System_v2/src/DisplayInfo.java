import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.font.*;
import java.awt.geom.*;
import java.io.PrintStream;
import java.util.ArrayList;

import javax.swing.*;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

@SuppressWarnings("serial")
public class DisplayInfo extends JPanel implements ActionListener {

	final int PAD = 20;
	JFrame f, error;
	JPanel p1;
	JButton back;
	Fillo fillo;
	static ArrayList<Double> input;
	String file, strQuery1, BitLog;
	Connection c;
	Recordset recordset;
	int ETI;
	Double[] data;

	public DisplayInfo(String BitLog) throws FilloException{
		
		setLayout(new BorderLayout());
		p1 = new JPanel();
		back = new JButton("Back");
		back.setPreferredSize(new Dimension(75,20));
		back.addActionListener(this);
		p1.add(back);
		
		f = new JFrame("CIRCM Data Management");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.add(this, BorderLayout.CENTER);
		f.add(p1, BorderLayout.PAGE_END);
		f.setSize(400, 400);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
		
		fillo = new Fillo();
		input = new ArrayList<Double>();
		strQuery1 = "Select ETI from Sheet1 where ETI <> ''";
		error = new JFrame();
		
		this.BitLog = BitLog;
		try {
			c = fillo.getConnection(BitLog);
		} catch (FilloException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(error,"Error: File not found");
		}

		try {
			recordset = c.executeQuery(strQuery1);
		} catch (FilloException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(error, "Error: Query did not find anything");
		}

		ETI = 0;
		
		data = getValues();
	}
	
	
	public Double[] getValues() throws FilloException {
		while (recordset.next()) {
			input.add(Double.parseDouble(recordset.getField(ETI).value())); //ME THATS FAILING(ETI);
		}
		Double[] x = input.toArray(new Double[input.size()]);
		recordset.close();
		c.close();
		return x;
	}

	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		int w = getWidth();
		int h = getHeight();

		// Draw Y-Axis.
		g2.draw(new Line2D.Double(PAD, PAD, PAD, h - PAD));

		// Draw X-Axis.
		g2.draw(new Line2D.Double(PAD, h - PAD, w - PAD, h - PAD));

		// Draw labels.
		Font font = g2.getFont();
		FontRenderContext frc = g2.getFontRenderContext();
		LineMetrics lm = font.getLineMetrics("0", frc);
		float sh = lm.getAscent() + lm.getDescent();

		// Y-Axis label.
		String s = "Number of Faults";
		float sy = PAD + ((h - 2 * PAD) - s.length() * sh) / 2 + lm.getAscent();
		for (int i = 0; i < s.length(); i++) {
			String letter = String.valueOf(s.charAt(i));
			float sw = (float) font.getStringBounds(letter, frc).getWidth();
			float sx = (PAD - sw) / 2;
			g2.drawString(letter, sx, sy);
			sy += sh;
		}

		// X-Axis label.
		s = "Time (ms)";
		sy = h - PAD + (PAD - sh) / 2 + lm.getAscent();
		float sw = (float) font.getStringBounds(s, frc).getWidth();
		float sx = (w - sw) / 2;
		g2.drawString(s, sx, sy);

		// Draw lines.
		double xInc = (double) (w - 2 * PAD) / (data.length - 1);
		double scale = (double) (h - 2 * PAD) / getMax();
		g2.setPaint(Color.green.darker());
		for (int i = 0; i < data.length - 1; i++) {
			double x1 = PAD + i * xInc;
			double y1 = h - PAD - scale * data[i];
			double x2 = PAD + (i + 1) * xInc;
			double y2 = h - PAD - scale * data[i + 1];
			g2.draw(new Line2D.Double(x1, y1, x2, y2));
		}

		// Mark data points.
		g2.setPaint(Color.red);
		for (int i = 0; i < data.length; i++) {
			double x = PAD + i * xInc;
			double y = h - PAD - scale * data[i];
			g2.fill(new Ellipse2D.Double(x - 2, y - 2, 4, 4));
		}
	}


	private Double getMax() {
		Double max = -Double.MAX_VALUE;
		for (int i = 0; i < data.length; i++) {
			if (data[i] > max)
				max = (Double) data[i];
		}
		return max;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == back){
			try {
				ModelInfo mi = new ModelInfo(ModelInfo.modelNumber);
				f.dispose();
			} catch (FilloException e1) {
				e1.printStackTrace();
			}
			
		}
	}
}