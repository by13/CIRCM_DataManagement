import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.xy.XYDataItem;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import com.codoid.products.exception.FilloException;

@SuppressWarnings("serial")
public class PlotGraph extends JFrame implements ActionListener {

	String PT1, PT2, param1, param2;
	JButton b;
	XYSeries PT1Series, PT2Series;

	public PlotGraph(String PT1, String PT2, String param1, String param2)
			throws FilloException {

		this.PT1 = PT1;
		this.PT2 = PT2;
		this.param1 = param1;
		this.param2 = param2;

		PT1Series = new XYSeries(PT1);
		PT2Series = new XYSeries(PT2);

		b = new JButton("back");

		initUI();
	}

	private void initUI() throws FilloException {

		XYDataset dataset = createDataset();
		JFreeChart chart = createChart(dataset);
		ChartPanel chartPanel = new ChartPanel(chart);
		JPanel p1 = new JPanel();
		chartPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
		chartPanel.setBackground(Color.white);
		p1.add(b);

		b.setPreferredSize(new Dimension(75, 20));
		b.addActionListener(this);

		add(chartPanel, BorderLayout.CENTER);
		add(p1, BorderLayout.SOUTH);

		pack();
		setTitle("Line chart");
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}

	private XYDataset createDataset() throws FilloException {

		dataSet1();
		dataSet2();
		
		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(PT1Series);
		dataset.addSeries(PT2Series);

		return dataset;
	}
	
	public void dataSet1() throws FilloException{
		AddToSeries ats = new AddToSeries(PT1, param1, param2);
		ats.getFile();
		ats.fillArrays();
		
		//NEED to get file for PT2 ect, repeat process.

		ArrayList<String> x = new ArrayList<String>();
		ArrayList<String> y = new ArrayList<String>();
		x = ats.getParam1();
		y = ats.getParam2();

		for (int i = 0; i < x.size(); i++) {
			PT1Series.add(Double.parseDouble(x.get(i)), Double.parseDouble(y.get(i)));
			System.out.print(PT1Series.getX(i) + ", ");
			System.out.print(PT1Series.getY(i) + " \n");
		}
		x.clear();
		y.clear();
	}
	
	public void dataSet2() throws FilloException{
		AddToSeries ats = new AddToSeries(PT2, param1, param2);
		ats.getFile();
		ats.fillArrays();
		
		//NEED to get file for PT2 ect, repeat process.

		ArrayList<String> x = new ArrayList<String>();
		ArrayList<String> y = new ArrayList<String>();
		x = ats.getParam1();
		y = ats.getParam2();

		for (int i = 0; i < x.size(); i++) {
			PT2Series.add(Double.parseDouble(x.get(i)), Double.parseDouble(y.get(i)));
			System.out.print(PT2Series.getX(i) + ", ");
			System.out.print(PT2Series.getY(i) + " \n");
		}
		x.clear();
		y.clear();
	}

	private JFreeChart createChart(final XYDataset dataset) {

		JFreeChart chart = ChartFactory.createXYLineChart(PT1, param1, param2,
				dataset, PlotOrientation.VERTICAL, true, true, false);

		XYPlot plot = chart.getXYPlot();

		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesStroke(0, new BasicStroke(2.0f));

		renderer.setSeriesPaint(1, Color.BLUE);
		renderer.setSeriesStroke(1, new BasicStroke(2.0f));

		plot.setRenderer(renderer);
		plot.setBackgroundPaint(Color.white);

		plot.setRangeGridlinesVisible(true);
		plot.setDomainGridlinesVisible(true);
	
        plot.setRangeGridlinePaint(Color.BLACK);
        plot.setDomainGridlinePaint(Color.BLACK);

		chart.getLegend().setBorder(BlockBorder.NONE);

		chart.setTitle(new TextTitle("Pointer/Tracker: " + PT1 + " vs " + PT2,
				new Font("Serif", Font.BOLD, 18)));

		return chart;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == b) {
			try {
				ChooseParameters p = new ChooseParameters(PT1, PT2);
				dispose();
			} catch (FilloException e1) {
				e1.printStackTrace();
			}
		}
	}
}
