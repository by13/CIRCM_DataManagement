import java.util.ArrayList;
import java.io.PrintStream;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

public class Models {

	Fillo f;
	static ArrayList<String> input;
	JFrame error;
	String file;
	String strQuery1, strQuery2, strQuery3;
	PrintStream o;
	Connection c;
	Recordset recordset;
	int ETI;

	public Models() {
		f = new Fillo();
		input = new ArrayList<String>();
		error = new JFrame();
		file = "H:\\My_Documents\\Projects\\CIRCM_Data_Management_System_v2\\src\\Models.xlsx";
		strQuery1 = "Select Models from Sheet1 where Models <> null";
		o = System.out;

	}

	public void initialise() throws FilloException {
		input.clear();
		// Connect File
		try {
			c = f.getConnection(file);
		} catch (FilloException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(error,
					"Error: Could not load CIRCM Models");
		}

		// Execute query and Put values into record set
		try {
			recordset = c.executeQuery(strQuery1);
		} catch (FilloException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(error,
					"Error: Could not Execute Query");
		}

		ETI = 0;

		getValues();
	}

	public void getValues() throws FilloException {
		// Put records into Array input
		while (recordset.next()) {
			input.add(recordset.getField(ETI).value());
		}
		recordset.close();
		c.close();

	}

	public void addNew(String modelNumber) throws FilloException {
		// Add a new PT to database
		c = f.getConnection(file);
		strQuery2 = "INSERT INTO Sheet1 (Models) VALUES ('" + modelNumber
				+ "')";
		c.executeUpdate(strQuery2);
		c.close();
		initialise();
	}

	public void delete(String modelNumber) throws FilloException {
		// delete from database
		c = f.getConnection(file);
		strQuery3 = "DELETE from Sheet1 WHERE Models = '" + modelNumber + "'";
		c.executeUpdate(strQuery3);
		c.close();
		initialise();
	}

	public ArrayList<String> getModels() {
		return input;
	}

}