import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

import com.codoid.products.exception.FilloException;

@SuppressWarnings("serial")
public class GUI extends JPanel implements ActionListener {

	static Models m;
	static JFrame f, error;
	JPanel p1, p2, p3;
	JLabel l1;
	JComboBox<String> cb1, cb2;
	JButton next, addnew;
	Font font;
	Dimension buttonDimension, panelDimension;

	public GUI() {
		m = new Models();
		f = new JFrame();

		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException | UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}

		setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));

		buttonDimension = new Dimension(75, 20);
		panelDimension = new Dimension(300, 20);

		p1 = new JPanel();
		p2 = new JPanel();
		l1 = new JLabel("Select Pointer/Trackers to Compare");
		cb1 = new JComboBox<String>();
		cb2 = new JComboBox<String>();
		next = new JButton("Next");
		addnew = new JButton("Add New");
		error = new JFrame();
		font = new Font("Calibri", Font.BOLD, 18);

		next.addActionListener(this);
		addnew.addActionListener(this);
		cb1.addActionListener(this);
		cb2.addActionListener(this);

		next.setEnabled(false);
		addnew.setEnabled(true);

		l1.setFont(font);
		next.setPreferredSize(buttonDimension);
		cb1.setPreferredSize(buttonDimension);
		cb2.setPreferredSize(buttonDimension);

		p1.setPreferredSize(panelDimension);
		p2.setPreferredSize(panelDimension);

		p1.add(cb1);
		p1.add(new JLabel(" vs "));
		p1.add(cb2);
		
		p2.add(addnew);
		p2.add(next);
		
		l1.setAlignmentX(Component.CENTER_ALIGNMENT);

		add(l1);
		add(p1);
		add(p2);
	}

	public void fillComboBox(ArrayList<String> input) {
		cb1.removeAllItems();
		cb2.removeAllItems();
		for (String i : input) {
			cb1.addItem(i);
			cb2.addItem(i);
		}
	}

	public String getNewNumber() {
		JFrame newModel = new JFrame();
		String modelNumber = null;
		Boolean present = true;

		while (present) {
			modelNumber = JOptionPane.showInputDialog(newModel,
					"Please enter new Model Number: ");
			if (Models.input.contains(modelNumber)) {
				present = true;
				JOptionPane.showMessageDialog(error,
						"Error: Model Number already exists!");
			} else {
				present = false;
				return modelNumber;
			}
		}
		return null;
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == addnew) {
			addNew();
		} else if (e.getSource() == next) {
			next();
		} else if (e.getSource() == cb1 || e.getSource() == cb2) {
			comboBox();
		}
	}

	public void addNew() {
		try {
			m.addNew(getNewNumber());
		} catch (FilloException e1) {
			e1.printStackTrace();
			JOptionPane.showMessageDialog(error, "Could not add new Model");
		}
		fillComboBox(m.getModels());
	}

	public void next() {
		f.setVisible(false);
		try {
			@SuppressWarnings("unused")
			ModelInfo x = new ModelInfo(cb1.getSelectedItem().toString(), cb2.getSelectedItem().toString() );
		} catch (FilloException e) {
			e.printStackTrace();
		}

	}

	public void comboBox() {
		next.setEnabled(true);
	}

	public static void main(String[] args) throws FilloException {
		GUI g = new GUI();

		f.add(g);
		f.setTitle("CIRCM Data Management");
		f.setSize(350, 125);
		f.setVisible(true);
		f.setLocationRelativeTo(null);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		m.initialise();

		g.fillComboBox(m.getModels());

	}

}
