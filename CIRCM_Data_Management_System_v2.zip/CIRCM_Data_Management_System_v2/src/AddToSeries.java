import java.util.ArrayList;
import java.io.PrintStream;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

public class AddToSeries {

	Fillo f;
	ArrayList<String> param1, param2;
	String file, PT, parameter1, parameter2;
	PrintStream o;
	Connection c;
	Recordset recordset;

	public AddToSeries(String PT, String parameter1, String parameter2)
			throws FilloException {
		this.PT = PT;
		this.parameter1 = parameter1;
		this.parameter2 = parameter2;
		param1 = new ArrayList<String>();
		param2 = new ArrayList<String>();
		f = new Fillo();
		o = System.out;

	}

	public void getFile() throws FilloException {

		c = f.getConnection("H:\\My_Documents\\Projects\\CIRCM_Data_Management_System_v2\\src\\Models.xlsx");
		recordset = c.executeQuery("SELECT BitLog1 FROM Sheet1 WHERE Models = "
				+ PT);
		while (recordset.next()) {
			file = recordset.getField("BitLog1").toString();
			o.println(file);
		}
		c.close();
		recordset.close();

	}

	public void fillArrays() throws FilloException {
		c = f.getConnection(file);
		recordset = c.executeQuery("SELECT * FROM Sheet1 WHERE + '" + parameter1 + "' != null");
		while (recordset.next()) {
			param1.add(recordset.getField(parameter1).toString());
		}
		c.close();
		recordset.close();

		c = f.getConnection(file);
		recordset = c.executeQuery("SELECT * FROM Sheet1 WHERE '" + parameter2 + "' != null");
		while (recordset.next()) {
			param2.add(recordset.getField(parameter2).toString());
		}
		c.close();
		recordset.close();
	}

	public ArrayList<String> getParam1() {
		return param1;
	}

	public ArrayList<String> getParam2() {
		return param2;
	}

}