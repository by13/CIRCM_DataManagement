package BITFaultAnalysisTool;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.codoid.products.exception.FilloException;

@SuppressWarnings("serial")
public class Graphing extends JPanel implements ActionListener {

	static JFrame f, error;
	JPanel p1, p2, p3;
	JLabel l1;
	JTextField path1, path2;
	JComboBox<String> cb1, cb2;
	JButton next, addnew, back, browse1, browse2;
	JFileChooser fc;
	Font font;
	Dimension buttonDimension, panelDimension;
	SerialNumbers sn;
	BitLogs b;

	public Graphing() throws FilloException {
		sn = new SerialNumbers();
		b = new BitLogs();

		initUI();

		f = new JFrame();

		setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));

		add(l1);
		add(p1);
		add(p2);
		add(p3);

		f.add(this);
		f.setTitle("CIRCM Data Management");
		f.setSize(400, 150);
		f.setVisible(true);
		f.setLocationRelativeTo(null);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		sn.initialise();
		fillComboBox(sn.getSerialNumbers());
	}

	private void initUI() {
		buttonDimension = new Dimension(75, 20);
		panelDimension = new Dimension(400, 20);

		p1 = new JPanel();
		p2 = new JPanel();
		p3 = new JPanel();
		fc = new JFileChooser();
		l1 = new JLabel("Select Pointer/Trackers to Compare");
		cb1 = new JComboBox<String>();
		cb2 = new JComboBox<String>();
		path1 = new JTextField();
		path2 = new JTextField();
		browse1 = new JButton("Browse");
		browse2 = new JButton("Browse");
		next = new JButton("Next");
		addnew = new JButton("Add New");
		back = new JButton("Back");
		error = new JFrame();
		font = new Font("Calibri", Font.BOLD, 18);

		next.addActionListener(this);
		addnew.addActionListener(this);
		back.addActionListener(this);
		cb1.addActionListener(this);
		cb2.addActionListener(this);
		browse1.addActionListener(this);
		browse2.addActionListener(this);

		next.setEnabled(false);
		addnew.setEnabled(true);

		l1.setFont(font);
		next.setPreferredSize(buttonDimension);
		addnew.setPreferredSize(buttonDimension);
		back.setPreferredSize(buttonDimension);
		cb1.setPreferredSize(buttonDimension);
		cb2.setPreferredSize(buttonDimension);
		browse1.setPreferredSize(buttonDimension);
		browse2.setPreferredSize(buttonDimension);

		path1.setPreferredSize(new Dimension(200, 20));
		path2.setPreferredSize(new Dimension(200, 20));

		p1.setPreferredSize(panelDimension);
		p2.setPreferredSize(panelDimension);

		p1.add(cb1);
		p1.add(path1);
		p1.add(browse1);

		p2.add(cb2);
		p2.add(path2);
		p2.add(browse2);

		p3.add(back);
		p3.add(addnew);
		p3.add(next);

		l1.setAlignmentX(Component.CENTER_ALIGNMENT);

	}

	public void fillComboBox(ArrayList<String> input) {
		cb1.removeAllItems();
		cb2.removeAllItems();
		for (int i = 0; i < input.size(); i++) {
			cb1.addItem(input.get(i).toString());
			cb2.addItem(input.get(i).toString());

		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == addnew) {
			addNew();
		} else if (e.getSource() == next) {
			try {
				next();
			} catch (FilloException e1) {
				e1.printStackTrace();
			}
		} else if (e.getSource() == back) {
			back();
		} else if (e.getSource() == cb1) {
			try {
				comboBox1();
			} catch (FilloException e1) {
				e1.printStackTrace();
			}
		} else if (e.getSource() == cb2) {
			try {
				comboBox2();
			} catch (FilloException e1) {
				e1.printStackTrace();
			}
		} else if (e.getSource() == browse1) {
			try {
				b.createNewLog(cb1.getSelectedItem().toString());
			} catch (FilloException | IOException e1) {
				e1.printStackTrace();
			}
		} else if (e.getSource() == browse2) {
			try {
				b.createNewLog(cb2.getSelectedItem().toString());
			} catch (FilloException | IOException e1) {
				e1.printStackTrace();
			}

		}
	}

	@SuppressWarnings("static-access")
	public String getNewNumber() {
		JFrame newModel = new JFrame();
		String serialNumber = null;
		Boolean present = true;

		while (present) {
			serialNumber = JOptionPane.showInputDialog(newModel,
					"Please enter new Pointer/Tracker serial number: ");
			if (sn.input.contains(serialNumber)) {
				present = true;
				JOptionPane.showMessageDialog(error,
						"Error: Model Number already exists!");
			} else {
				present = false;
				return serialNumber;
			}
		}
		return null;
	}

	public void addNew() {
		try {
			sn.addNew(getNewNumber());
		} catch (FilloException e1) {
			e1.printStackTrace();
			JOptionPane.showMessageDialog(error, "Could not add new PT");
		}
		fillComboBox(sn.getSerialNumbers());
	}

	public void next() throws FilloException {
		@SuppressWarnings("unused")
		ChooseGraphParameters cp = new ChooseGraphParameters(cb1.getSelectedItem()
				.toString(), cb2.getSelectedItem().toString());
		f.dispose();

	}

	public void back() {
		try {
			HomePage.main(null);
		} catch (FilloException e) {
			e.printStackTrace();
		}
		f.dispose();
	}

	public void comboBox1() throws FilloException {
		next.setEnabled(true);
		path1.setText(b.getBitlog(cb1.getSelectedItem().toString()));
	}

	public void comboBox2() throws FilloException {
		path2.setText(b.getBitlog(cb2.getSelectedItem().toString()));
	}
}
