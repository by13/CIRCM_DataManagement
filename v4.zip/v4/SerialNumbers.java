package BITFaultAnalysisTool;

import java.io.PrintStream;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

public class SerialNumbers {
	Fillo f;
	static ArrayList<String> input;
	JFrame error;
	static String file;
	String strQuery1;
	String strQuery2;
	String strQuery3;
	PrintStream o;
	Connection c;
	Recordset recordset;
	int ETI;

	public SerialNumbers() {
		f = new Fillo();
		input = new ArrayList<String>();
		error = new JFrame();
		file = "Z:\\SPT\\CIRCM\\Users\\Bradley\\BITFaultAnalysisTool\\SerialNumbers.xlsx";
		strQuery1 = "Select SerialNumber from Sheet1 where SerialNumber <> null";
		o = System.out;

	}

	public void initialise() throws FilloException {
		// Connect File
		try {
			c = f.getConnection(file);
		} catch (FilloException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(error,
					"Error: Could not load CIRCM SerialNumbers");
		}

		// Execute query and Put values into record set
		try {
			recordset = c.executeQuery(strQuery1);
		} catch (FilloException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(error,
					"Error: Could not Execute Query");
		}

		ETI = 0;

		setValues();
	}

	public void setValues() throws FilloException {
		// Put records into Array input
		while (recordset.next()) {
			input.add(recordset.getField(ETI).value());
		}
		recordset.close();
		c.close();

	}

	public void addNew(String serialNumber) throws FilloException {
		// Add a new PT to database
		c = f.getConnection(file);
		strQuery2 = "INSERT INTO Sheet1 (SerialNumber) VALUES ('" + serialNumber
				+ "')";
		c.executeUpdate(strQuery2);
		c.close();
		initialise();
	}

	public void delete(String serialNumber) throws FilloException {
		// delete from database
		c = f.getConnection(file);
		strQuery3 = "DELETE from Sheet1 WHERE SerialNumber = '" + serialNumber + "'";
		c.executeUpdate(strQuery3);
		c.close();
		initialise();
	}

	public ArrayList<String> getSerialNumbers() {
		return input;
	}

}
