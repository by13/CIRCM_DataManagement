package BITFaultAnalysisTool;

import java.awt.AWTException;
import java.awt.Desktop;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Decoding {

	JFileChooser fc = new JFileChooser();

	public void decodeFile() throws IOException, InterruptedException {
		String decodeUtility = ("D:\\Bitlogs\\BitlogDecodeUtilityCmp.exe");
		File decodeUtilityParent = new File(decodeUtility).getParentFile();

		fc.showOpenDialog(new JFrame());

		String path = fc.getSelectedFile().getAbsolutePath();
		File file = new File(path);

		if (!file.exists()) {
			throw new IllegalArgumentException("The file " + path
					+ " does not exist");
		} else if (file.exists()) {

			moveToDDrive(file);
			Process process = Runtime.getRuntime().exec(decodeUtility, null,
					decodeUtilityParent);
			process.waitFor();

			convertToExcel(decodeUtilityParent);
		}
	}

	public void moveToDDrive(File Bitlog) throws IOException {
		Path source = FileSystems.getDefault().getPath(Bitlog.getPath());
		Path newdir = FileSystems.getDefault().getPath("D:\\");

		Files.copy(source, newdir.resolve(source.getFileName()),
				StandardCopyOption.REPLACE_EXISTING);
	}

	public void convertToExcel(File decodeUtilityParent) throws IOException,
			InterruptedException {

		Desktop desktop = Desktop.getDesktop();
		File file = new File("D:\\Bitlog.bin");
		Object[] options = { "Add at end of existing Bitlog",
				"Add to new Bitlog" };

		if (file.exists()) {
			int n = JOptionPane.showOptionDialog(new JFrame("Add Bitlog"),
					"What would you like to do with this BitLog?",
					"Add Bitlog", JOptionPane.YES_NO_CANCEL_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, options, options[1]);

			if (n == JOptionPane.YES_OPTION) {
				desktop.open(new File(decodeUtilityParent.getAbsolutePath()
						.concat("\\BitDecode.txt")));
				fc.showOpenDialog(new JFrame());
				fc.getSelectedFile();

			} else if (n == JOptionPane.NO_OPTION) {
				desktop.open(new File(
						"C:\\Program Files (x86)\\Microsoft Office\\Office14\\EXCEL.EXE"));
				Thread.sleep(2000);
				desktop.open(new File(decodeUtilityParent.getAbsolutePath()
						.concat("\\BitDecode.txt")));
				copyAndPaste();
			}
		}
	}

	private void copyAndPaste() throws InterruptedException {
		try {
			Robot robot = new Robot();
			robot.delay(500);

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_A);
			robot.keyRelease(KeyEvent.VK_A);
			robot.keyRelease(KeyEvent.VK_CONTROL);

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_C);
			robot.keyRelease(KeyEvent.VK_C);
			robot.keyRelease(KeyEvent.VK_CONTROL);

			robot.keyPress(KeyEvent.VK_ALT);
			robot.keyPress(KeyEvent.VK_F4);
			robot.keyRelease(KeyEvent.VK_F4);
			robot.keyRelease(KeyEvent.VK_ALT);

			robot.delay(200);

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);

			robot.keyPress(KeyEvent.VK_ALT);
			robot.keyPress(KeyEvent.VK_F4);
			robot.keyRelease(KeyEvent.VK_F4);
			robot.keyRelease(KeyEvent.VK_ALT);

			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			e.printStackTrace();
		}
	}
}
