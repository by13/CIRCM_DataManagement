package BITFaultAnalysisTool;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import com.codoid.products.exception.FilloException;

@SuppressWarnings("serial")
public class PlotGraph extends JFrame implements ActionListener {

	String PT1, PT2, param1, param2;
	JButton b, export, exit;
	JCheckBox cb;
	ChartPanel chartPanel;
	JPanel p1;
	XYSeries PT1Series, PT2Series;
	XYDataset dataset;
	static JFreeChart chart;
	int flipFlop = 1;

	public PlotGraph(String PT1, String PT2, String param1, String param2)
			throws FilloException {

		this.PT1 = PT1;
		this.PT2 = PT2;
		this.param1 = param1;
		this.param2 = param2;

		PT1Series = new XYSeries(PT1);
		PT2Series = new XYSeries(PT2);

		b = new JButton("back");
		export = new JButton("export");
		exit = new JButton("exit");
		p1 = new JPanel();
		cb = new JCheckBox("Toggle LineGraph/ScatterGraph");

		cb.addActionListener(this);
		b.setPreferredSize(new Dimension(75, 20));
		b.addActionListener(this);
		export.setPreferredSize(new Dimension(75, 20));
		export.addActionListener(this);
		exit.setPreferredSize(new Dimension(75, 20));
		exit.addActionListener(this);

		dataset = createDataset();
		chart = createChartScatter(dataset);
		chartPanel = new ChartPanel(chart);

		initUI();
	}

	private void initUI() throws FilloException {

		chartPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
		chartPanel.setBackground(Color.white);
		p1.add(cb);
		p1.add(b);
		p1.add(export);
		p1.add(exit);

		add(chartPanel, BorderLayout.CENTER);
		add(p1, BorderLayout.SOUTH);

		pack();
		setTitle("Line chart");
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}

	private XYDataset createDataset() throws FilloException {

		dataSet1();
		dataSet2();

		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(PT1Series);
		dataset.addSeries(PT2Series);

		return dataset;
	}

	public void dataSet1() throws FilloException {
		AddToSeries ats = new AddToSeries(PT1, param1, param2);
		ats.getFile();
		ats.fillArrays();

		ArrayList<String> x = new ArrayList<String>();
		ArrayList<String> y = new ArrayList<String>();
		x = ats.getParam1();
		y = ats.getParam2();

		for (int i = 0; i < x.size(); i++) {
			PT1Series.add(Double.parseDouble(x.get(i)),
					Double.parseDouble(y.get(i)));
		}
		x.clear();
		y.clear();
	}

	public void dataSet2() throws FilloException {
		AddToSeries ats = new AddToSeries(PT2, param1, param2);
		ats.getFile();
		ats.fillArrays();

		ArrayList<String> x = new ArrayList<String>();
		ArrayList<String> y = new ArrayList<String>();
		x = ats.getParam1();
		y = ats.getParam2();

		for (int i = 0; i < x.size(); i++) {
			PT2Series.add(Double.parseDouble(x.get(i)),
					Double.parseDouble(y.get(i)));
		}
		x.clear();
		y.clear();
	}

	private JFreeChart createChartScatter(final XYDataset dataset) {

		JFreeChart chart = ChartFactory.createScatterPlot(PT1, param1, param2,
				dataset, PlotOrientation.VERTICAL, true, true, false);

		XYPlot plot = chart.getXYPlot();

		XYItemRenderer renderer = plot.getRenderer();

		Shape shape = new Ellipse2D.Double(0, 0, 2, 2);
		renderer.setBaseShape(shape);

		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesShape(0, shape);

		renderer.setSeriesPaint(1, Color.BLUE);
		renderer.setSeriesShape(1, shape);

		plot.setRenderer(renderer);
		plot.setBackgroundPaint(Color.white);

		plot.setRangeGridlinesVisible(true);
		plot.setDomainGridlinesVisible(true);

		plot.setRangeGridlinePaint(Color.BLACK);
		plot.setDomainGridlinePaint(Color.BLACK);

		chart.getLegend().setBorder(BlockBorder.NONE);
		chart.setTitle(new TextTitle("Pointer/Tracker: " + PT1 + " vs " + PT2,
				new Font("Serif", Font.BOLD, 18)));

		return chart;
	}

	private JFreeChart createChartLine(final XYDataset dataset) {

		JFreeChart chart = ChartFactory.createXYLineChart(PT1, param1, param2,
				dataset, PlotOrientation.VERTICAL, true, true, false);

		XYPlot plot = chart.getXYPlot();

		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesStroke(0, new BasicStroke(2.0f));

		renderer.setSeriesPaint(1, Color.BLUE);
		renderer.setSeriesStroke(1, new BasicStroke(2.0f));

		plot.setRenderer(renderer);
		plot.setBackgroundPaint(Color.white);

		plot.setRangeGridlinesVisible(true);
		plot.setDomainGridlinesVisible(true);

		plot.setRangeGridlinePaint(Color.BLACK);
		plot.setDomainGridlinePaint(Color.BLACK);

		chart.getLegend().setBorder(BlockBorder.NONE);

		chart.setTitle(new TextTitle("Pointer/Tracker: " + PT1 + " vs " + PT2,
				new Font("Serif", Font.BOLD, 18)));

		return chart;
	}

	public void saveToFile() throws IOException {

		try {
			ChartUtilities
					.saveChartAsPNG(
							new File(
									"Z:\\SPT\\CIRCM\\Users\\Bradley\\BITFaultAnalysisTool\\LineGraph.png"),
							chart, 500, 300);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Desktop desktop = Desktop.getDesktop();
		desktop.open(new File("Z:\\SPT\\CIRCM\\Users\\Bradley\\BITFaultAnalysisTool\\LineGraph.png"));
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == b) {
			try {
				@SuppressWarnings("unused")
				ChooseGraphParameters p = new ChooseGraphParameters(PT1, PT2);
				dispose();
			} catch (FilloException e1) {
				e1.printStackTrace();
			}

		} else if (e.getSource() == exit) {
			this.dispose();

		} else if (e.getSource() == export) {
			try {
				saveToFile();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

		} else if (e.getSource() == cb) {
			switch (flipFlop) {
			case 0:
				chart = createChartScatter(dataset);
				chartPanel = new ChartPanel(chart);
				try {
					initUI();
				} catch (FilloException e1) {
					e1.printStackTrace();
				}
				flipFlop++;
				break;
			case 1:
				chart = createChartLine(dataset);
				chartPanel = new ChartPanel(chart);
				try {
					initUI();
				} catch (FilloException e1) {
					e1.printStackTrace();
				}
				flipFlop--;
				break;
			}
		}
	}
}
