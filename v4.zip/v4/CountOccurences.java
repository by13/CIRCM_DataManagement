package BITFaultAnalysisTool;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

@SuppressWarnings("serial")
public class CountOccurences extends JFrame implements ActionListener {

	JPanel p1;
	JButton exit, back, export;
	Font font;
	String testName, testID;
	Dimension buttonDimension, panelDimension;
	File dir;
	Fillo fillo = new Fillo();
	Connection connection;
	ArrayList<File> bitlogs;
	Recordset recordset;
	ArrayList<Integer> occurrences;
	JFreeChart chart;

	public CountOccurences(String testName) throws FilloException {

		this.testName = testName;
		setLayout(new BoxLayout(this.getContentPane(), BoxLayout.PAGE_AXIS));

		getTestID(testName);
		countOccurences();

		initUI();

	}

	public void initUI() {

		buttonDimension = new Dimension(75, 20);
		panelDimension = new Dimension(300, 20);

		p1 = new JPanel();
		exit = new JButton("Exit");
		back = new JButton("Back");
		export = new JButton("Export");
		font = new Font("Calibri", Font.PLAIN, 11);

		exit.addActionListener(this);
		back.addActionListener(this);
		export.addActionListener(this);

		exit.setPreferredSize(buttonDimension);
		back.setPreferredSize(buttonDimension);
		export.setPreferredSize(buttonDimension);

		p1.setPreferredSize(panelDimension);
		p1.add(back);
		p1.add(export);
		p1.add(exit);

		CategoryDataset dataset = createDataset();

		chart = createChart(dataset);
		ChartPanel chartPanel = new ChartPanel(chart);
		chartPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
		chartPanel.setBackground(Color.white);

		add(chartPanel);
		add(p1);
		pack();
		setTitle("Bar chart");
		setVisible(true);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	private CategoryDataset createDataset() {
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		for (int i = 0; i < bitlogs.size(); i++) {
			dataset.addValue(occurrences.get(i), "Occurences", bitlogs.get(i)
					.getName());
		}

		return dataset;
	}

	private JFreeChart createChart(CategoryDataset dataset) {

		JFreeChart barChart = ChartFactory.createBarChart("Occurences of "
				+ testName, "", "Occurences", dataset,
				PlotOrientation.VERTICAL, false, true, false);

		return barChart;
	}

	public void getTestID(String testName) throws FilloException {
		connection = fillo
				.getConnection("Z:\\SPT\\CIRCM\\Users\\Bradley\\BITFaultAnalysisTool\\TestNames.xlsx");
		String strQuery = "SELECT TestID from Sheet1 where TestName = '"
				+ testName + "'";
		recordset = connection.executeQuery(strQuery);

		while (recordset.next()) {
			testID = recordset.getField("testID");
		}

		recordset.close();
		connection.close();
	}

	public void countOccurences() throws FilloException {
		dir = new File(
				"Z:\\SPT\\CIRCM\\Users\\Bradley\\BITFaultAnalysisTool\\BitLogs");
		// adds all bitlogs in dir to arraylist bitlogs
		bitlogs = new ArrayList<File>(Arrays.asList(dir.listFiles()));
		occurrences = new ArrayList<Integer>();
		int value = 0;
		for (int i = 0; i < bitlogs.size(); i++) {
			connection = fillo.getConnection(bitlogs.get(i).getAbsolutePath());

			String strQuery = "SELECT * from Sheet1";
			recordset = connection.executeQuery(strQuery);
			occurrences.add(new Integer(value));
			while (recordset.next()) {
				if (recordset.getField("Failed BIT Test ID").equals(testID)) {
					occurrences.set(i, value++);
				}
			}

			recordset.close();
			connection.close();
		}

	}

	@SuppressWarnings("unused")
	public void back() {
		try {
			SelectTest st = new SelectTest();
			this.dispose();
		} catch (FilloException e) {
			e.printStackTrace();
		}

	}

	public void exportData() throws IOException {
		PrintWriter writer = new PrintWriter("Occurrences.txt", "UTF-8");
		writer.println(testName);
		for (int i = 0; i < bitlogs.size(); i++) {
			writer.println("BitLog: " + bitlogs.get(i).getName() + "    "
					+ "Occurrences: " + occurrences.get(i));
		}
		writer.close();
		Desktop desktop = Desktop.getDesktop();
		desktop.open(new File(
				"Z:\\SPT\\CIRCM\\Users\\Bradley\\BITFaultAnalysisTool\\Occurrences.txt"));
		
		try {
			ChartUtilities
					.saveChartAsPNG(
							new File(
									"Z:\\SPT\\CIRCM\\Users\\Bradley\\BITFaultAnalysisTool\\Occurrences.png"),
							chart, 500, 300);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == export) {
			try {
				exportData();
			} catch (FileNotFoundException | UnsupportedEncodingException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} else if (e.getSource() == exit) {
			System.exit(0);
		} else if (e.getSource() == back) {
			back();
		}
	}
}
