package BITFaultAnalysisTool;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import com.codoid.products.exception.FilloException;

@SuppressWarnings("serial")
public class HomePage extends JFrame implements ActionListener {

	JLabel l1;
	JButton search, graph, decode;
	JPanel p1;
	static JFrame homePage;

	public HomePage() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException | UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}

		l1 = new JLabel("BIT Fault Analysis Tool");
		search = new JButton("Search for Parameters");
		graph = new JButton("Graph Parameters");
		decode = new JButton("Decode BitLog.bin File");
		p1 = new JPanel();
		homePage = new JFrame("CIRCM Data Management System");

		l1.setFont(new Font("Calibri", Font.BOLD, 18));
		l1.setHorizontalAlignment(JLabel.CENTER);

		search.addActionListener(this);
		graph.addActionListener(this);
		decode.addActionListener(this);

		search.setPreferredSize(new Dimension(200, 20));
		graph.setPreferredSize(new Dimension(200, 20));
		decode.setPreferredSize(new Dimension(200, 20));

		p1.add(search);
		p1.add(graph);
		p1.add(decode);

		add(l1, BorderLayout.NORTH);
		add(p1);
	}

	@SuppressWarnings("unused")
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == search) {
			Object[] options = {
					"Search for Flag Occurence across all PTs",
					"Search for Parameters between Values on one PT" };

			int n = JOptionPane.showOptionDialog(new JFrame("Search"),
					"What would you like to do a Search on?",
					"Add Bitlog", JOptionPane.YES_NO_CANCEL_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, options, options[1]);

			if (n == JOptionPane.YES_OPTION) {
				try {
					SelectTest st = new SelectTest();
					this.dispose();
				} catch (FilloException e1) {
					e1.printStackTrace();
				}
			} else if (n == JOptionPane.NO_OPTION) {
				try {
					Searching s = new Searching();
					this.dispose();
				} catch (FilloException e1) {
					e1.printStackTrace();
				}
			}

		} else if (e.getSource() == graph) {
			try {
				Graphing g = new Graphing();
				this.dispose();
			} catch (FilloException e1) {
				e1.printStackTrace();
			}
			this.dispose();
		} else if (e.getSource() == decode) {
			Decoding d = new Decoding();
			try {
				d.decodeFile();
			} catch (IOException | InterruptedException e1) {
				e1.printStackTrace();
			}
		}
	}

	public static void main(String[] args) throws FilloException {
		HomePage hp = new HomePage();
		hp.setTitle("CIRCM Data Management System");
		hp.setVisible(true);
		hp.setSize(450, 120);
		hp.setLocationRelativeTo(null);
		hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
}
