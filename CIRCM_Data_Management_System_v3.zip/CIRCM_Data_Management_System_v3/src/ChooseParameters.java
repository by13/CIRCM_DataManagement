import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;

import com.codoid.products.exception.FilloException;

@SuppressWarnings("serial")
public class ChooseParameters extends JPanel implements ActionListener {

	JLabel l1, l2;
	JPanel p1, p2;
	JComboBox<String> cb1, cb2;
	JButton next, back;
	Parameters p;
	JFrame f;
	Dimension buttonDimension, panelDimension;
	String PT1, PT2;

	Font font;

	ChooseParameters(String PT1, String PT2) throws FilloException {
		this.PT1 = PT1;
		this.PT2 = PT2;

		setLayout(new GridLayout(3, 1));

		buttonDimension = new Dimension(75, 20);
		panelDimension = new Dimension(300, 20);
		font = new Font("Calibri", Font.BOLD, 18);

		p = new Parameters();
		l1 = new JLabel("Pointer/Tracker: " + PT1 + " vs " + PT2);
		l2 = new JLabel("(X-Axis)  vs  (Y-Axis)");
		p1 = new JPanel();
		p2 = new JPanel();
		cb1 = new JComboBox<String>();
		cb2 = new JComboBox<String>();
		next = new JButton("next");
		back = new JButton("back");
		f = new JFrame();

		next.setPreferredSize(buttonDimension);
		back.setPreferredSize(buttonDimension);
		p1.setPreferredSize(panelDimension);
		p2.setPreferredSize(panelDimension);

		l1.setFont(font);
		l1.setHorizontalAlignment(SwingConstants.CENTER);
		next.setEnabled(false);

		next.addActionListener(this);
		back.addActionListener(this);
		cb1.addActionListener(this);
		cb2.addActionListener(this);

		p1.add(cb1);
		p1.add(l2);
		p1.add(cb2);
		p2.add(back);
		p2.add(next);

		add(l1);
		add(p1);
		add(p2);

		f.setTitle("CIRCM Data Management");
		f.setSize(450, 125);
		f.setVisible(true);
		f.setLocationRelativeTo(null);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.add(this);

		p.initialise();

		fillComboBoxes(p.getParameters());

	}

	public void fillComboBoxes(ArrayList<String> input) {
		cb1.removeAllItems();
		cb2.removeAllItems();

		for (int i = 0; i < input.size(); i++) {
			cb1.addItem(input.get(i));
			cb2.addItem(input.get(i));
		}
	}

	@SuppressWarnings("unused")
	public void back() {
		try {
			ModelInfo2 i = new ModelInfo2(PT1, PT2);
			f.dispose();
		} catch (FilloException e1) {
			e1.printStackTrace();
		}
	}

	@SuppressWarnings("unused")
	public void next() throws FilloException {
		PlotGraph p = new PlotGraph(PT1, PT2, cb1.getSelectedItem().toString(),
				cb2.getSelectedItem().toString());
		f.dispose();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == next) {
			try {
				next();
			} catch (FilloException e1) {
				e1.printStackTrace();
			}
		} else if (e.getSource() == back) {
			back();
		} else if (e.getSource() == cb1 || e.getSource() == cb2) {
			next.setEnabled(true);
		}

	}

}