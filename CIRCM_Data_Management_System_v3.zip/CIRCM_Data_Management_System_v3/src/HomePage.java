import java.awt.AWTException;
import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

import javax.swing.*;

import com.codoid.products.exception.FilloException;

@SuppressWarnings("serial")
public class HomePage extends JFrame implements ActionListener {

	JLabel l1;
	JButton search, graph, decode;
	JPanel p1;
	JFileChooser fc;
	static JFrame homePage;

	public HomePage() {

		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException | UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}

		l1 = new JLabel("CIRCM Data Management Syetem");
		search = new JButton("Search for Parameters");
		graph = new JButton("Graph parameters");
		decode = new JButton("Decode BitLog.bin File");
		p1 = new JPanel();
		homePage = new JFrame("CIRCM Data Management System");
		fc = new JFileChooser();

		l1.setFont(new Font("Calibri", Font.BOLD, 18));
		l1.setHorizontalAlignment(JLabel.CENTER);

		search.addActionListener(this);
		graph.addActionListener(this);
		decode.addActionListener(this);

		search.setPreferredSize(new Dimension(200, 20));
		graph.setPreferredSize(new Dimension(200, 20));
		decode.setPreferredSize(new Dimension(200, 20));

		p1.add(search);
		p1.add(graph);
		p1.add(decode);

		add(l1, BorderLayout.NORTH);
		add(p1);
	}

	@SuppressWarnings("unused")
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == search) {
			try {
				Searching s = new Searching();
			} catch (FilloException e1) {
				e1.printStackTrace();
			}
			this.dispose();
		} else if (e.getSource() == graph) {
			try {
				Graphing g = new Graphing();
			} catch (FilloException e1) {
				e1.printStackTrace();
			}
			this.dispose();
		} else if (e.getSource() == decode) {
			try {
				try {
					decodeFile();
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}

	public void decodeFile() throws IOException, InterruptedException {
		String decodeUtility = ("D:\\Bitlogs\\BitlogDecodeUtilityCmp.exe");
		File decodeUtilityParent = new File(decodeUtility).getParentFile();
		fc.showOpenDialog(new JFrame());
		String path = fc.getSelectedFile().getAbsolutePath();
		File file = new File(path);

		if (!file.exists()) {
			throw new IllegalArgumentException("The file " + path
					+ " does not exist");
		} else if (file.exists()) {
			moveToDDrive(file);
			Process process = Runtime.getRuntime().exec(decodeUtility, null,
					decodeUtilityParent);
			process.waitFor();
			convertToExcel(decodeUtilityParent);
		}
	}

	public void moveToDDrive(File Bitlog) throws IOException {
		Path source = FileSystems.getDefault().getPath(Bitlog.getPath());
		Path newdir = FileSystems.getDefault().getPath("D:\\");

		Files.copy(source, newdir.resolve(source.getFileName()),
				StandardCopyOption.REPLACE_EXISTING);
	}

	public void convertToExcel(File decodeUtilityParent) throws IOException,
			InterruptedException {

		File file = new File("D:\\Bitlog.bin");

		Object[] options = { "Add at end of existing Bitlog",
				"Add to new Bitlog" };

		Desktop desktop = Desktop.getDesktop();
		if (file.exists()) {
			int n = JOptionPane.showOptionDialog(new JFrame("Add Bitlog"),
					"What would you like to do with this BitLog?",
					"Add Bitlog", JOptionPane.YES_NO_CANCEL_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, options, options[1]);

			if (n == JOptionPane.YES_OPTION) {
				desktop.open(new File(decodeUtilityParent.getAbsolutePath()
						.concat("\\BitDecode.txt")));
				fc.showOpenDialog(new JFrame());
				fc.getSelectedFile();

			} else if (n == JOptionPane.NO_OPTION) {
				desktop.open(new File(
						"C:\\Program Files (x86)\\Microsoft Office\\Office14\\EXCEL.EXE"));
				Thread.sleep(2000);
				desktop.open(new File(decodeUtilityParent.getAbsolutePath()
						.concat("\\BitDecode.txt")));
				copyAndPaste();
			}
		}
	}

	private void copyAndPaste() throws InterruptedException {
		try {
			Robot robot = new Robot();
			robot.delay(500);

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_A);
			robot.keyRelease(KeyEvent.VK_A);
			robot.keyRelease(KeyEvent.VK_CONTROL);

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_C);
			robot.keyRelease(KeyEvent.VK_C);
			robot.keyRelease(KeyEvent.VK_CONTROL);

			robot.keyPress(KeyEvent.VK_ALT);
			robot.keyPress(KeyEvent.VK_F4);
			robot.keyRelease(KeyEvent.VK_F4);
			robot.keyRelease(KeyEvent.VK_ALT);

			robot.delay(200);

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);

			robot.keyPress(KeyEvent.VK_ALT);
			robot.keyPress(KeyEvent.VK_F4);
			robot.keyRelease(KeyEvent.VK_F4);
			robot.keyRelease(KeyEvent.VK_ALT);

			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		HomePage hp = new HomePage();
		hp.setTitle("CIRCM Data Management System");
		hp.setVisible(true);
		hp.setSize(450, 120);
		hp.setLocationRelativeTo(null);
		hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
}
