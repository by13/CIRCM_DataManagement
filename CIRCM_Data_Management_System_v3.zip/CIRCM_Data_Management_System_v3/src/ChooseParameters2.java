import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

import com.codoid.products.exception.FilloException;

@SuppressWarnings("serial")
public class ChooseParameters2 extends JFrame implements ActionListener {

	JPanel p1, p2, p3;
	JLabel l1;
	JTextField num1, num2;
	JComboBox<String> cb1, cb2;
	Parameters p;
	JButton next, back;
	Font font;
	Dimension buttonDimension, panelDimension;
	String PT;

	public ChooseParameters2(String PT) throws FilloException {

		setLayout(new BoxLayout(this.getContentPane(), BoxLayout.PAGE_AXIS));
		this.PT = PT;

		initUI();

		setTitle("CIRCM Data Management System");
		setVisible(true);
		setSize(400, 145);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		p.initialise();
		fillComboBox(p.getParameters());

	}

	public void initUI() {
		buttonDimension = new Dimension(75, 20);
		panelDimension = new Dimension(300, 20);
		p = new Parameters();

		p1 = new JPanel();
		p2 = new JPanel();
		p3 = new JPanel();
		l1 = new JLabel("Pointer/Tracker: " + PT);
		cb1 = new JComboBox<String>();
		cb2 = new JComboBox<String>();
		num1 = new JTextField();
		num2 = new JTextField();
		next = new JButton("Next");
		back = new JButton("Back");
		font = new Font("Calibri", Font.BOLD, 18);

		next.addActionListener(this);
		back.addActionListener(this);
		cb1.addActionListener(this);
		cb2.addActionListener(this);

		next.setEnabled(false);
		back.setEnabled(false);

		l1.setFont(font);
		l1.setAlignmentX(Component.CENTER_ALIGNMENT);

		next.setPreferredSize(buttonDimension);
		back.setPreferredSize(buttonDimension);
		num1.setPreferredSize(buttonDimension);
		num2.setPreferredSize(buttonDimension);

		p1.setPreferredSize(panelDimension);
		p2.setPreferredSize(panelDimension);

		p1.add(new JLabel("Find: "));
		p1.add(cb1);

		p1.add(new JLabel("when: "));
		p1.add(cb2);

		p2.add(new JLabel("is between: "));
		p2.add(num1);
		p2.add(new JLabel(" & "));
		p2.add(num2);

		p3.add(back);
		p3.add(next);

		add(l1);
		add(p1);
		add(p2);
		add(p3);
	}

	public void fillComboBox(ArrayList<String> input) {
		cb1.removeAllItems();
		cb2.removeAllItems();
		for (String i : input) {
			cb1.addItem(i);
			cb2.addItem(i);
		}
	}

	public void comboBoxUpdate() {
		next.setEnabled(true);
		back.setEnabled(true);
	}

	@SuppressWarnings("unused")
	public void back() throws FilloException {
		Searching s = new Searching();
		this.dispose();
	}

	@SuppressWarnings("unused")
	public void next() throws FilloException {
		if (num1.getText().isEmpty() || num2.getText().isEmpty()) {
			JOptionPane.showMessageDialog(new JFrame(),
					"Error: Please enter values into text boxes");
		} else {
			// try {
			double paramValue1 = Double.parseDouble(num1.getText());
			double paramValue2 = Double.parseDouble(num2.getText());
			DisplaySearch ds = new DisplaySearch(PT, paramValue1, paramValue2,
					cb1.getSelectedItem().toString(), cb2.getSelectedItem()
							.toString());
			this.dispose();
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == next) {
			try {
				next();
			} catch (FilloException e1) {
				e1.printStackTrace();
			}
		} else if (e.getSource() == back) {
			try {
				back();
			} catch (FilloException e1) {
				e1.printStackTrace();
			}
		} else if (e.getSource() == cb1) {
			comboBoxUpdate();

		} else if (e.getSource() == cb2) {
			comboBoxUpdate();
		}
	}
}
