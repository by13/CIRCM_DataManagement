import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

import com.codoid.products.exception.FilloException;

@SuppressWarnings("serial")
public class Searching extends JFrame implements ActionListener {

	JPanel p1, p2, p3;
	JLabel l1;
	JComboBox<String> cb;
	Models m;
	JButton next, back, addnew;
	Font font;
	Dimension buttonDimension, panelDimension;

	public Searching() throws FilloException {

		setLayout(new BoxLayout(this.getContentPane(), BoxLayout.PAGE_AXIS));

		initUI();

		setTitle("CIRCM Data Management System");
		setVisible(true);
		setSize(400, 125);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		m.initialise();
		fillComboBox(m.getModels());

	}

	public void initUI() {
		buttonDimension = new Dimension(75, 20);
		panelDimension = new Dimension(300, 20);
		m = new Models();

		p1 = new JPanel();
		p2 = new JPanel();
		l1 = new JLabel("Select Pointer/Tracker");
		cb = new JComboBox<String>();
		next = new JButton("Next");
		back = new JButton("Back");
		addnew = new JButton("Add New");
		font = new Font("Calibri", Font.BOLD, 18);

		next.addActionListener(this);
		back.addActionListener(this);
		addnew.addActionListener(this);
		cb.addActionListener(this);

		next.setEnabled(false);
		back.setEnabled(false);
		addnew.setEnabled(true);

		l1.setFont(font);
		next.setPreferredSize(buttonDimension);
		back.setPreferredSize(buttonDimension);
		cb.setPreferredSize(new Dimension(100, 20));

		p1.setPreferredSize(panelDimension);
		p2.setPreferredSize(panelDimension);

		p1.add(cb);

		p2.add(back);
		p2.add(addnew);
		p2.add(next);

		l1.setAlignmentX(Component.CENTER_ALIGNMENT);

		add(l1);
		add(p1);
		add(p2);
	}

	public void fillComboBox(ArrayList<String> input) {
		cb.removeAllItems();
		for (String i : input) {
			cb.addItem(i);
		}
	}

	public void comboBoxUpdate() {
		next.setEnabled(true);
		back.setEnabled(true);
	}

	public void back() {
		HomePage.main(null);
		this.dispose();
	}

	@SuppressWarnings("unused")
	public void next() throws FilloException {
		ChooseParameters2 cp2 = new ChooseParameters2(cb.getSelectedItem()
				.toString());
		this.dispose();
	}
	
	public String getNewNumber() {
		JFrame newModel = new JFrame();
		String modelNumber = null;
		Boolean present = true;

		while (present) {
			modelNumber = JOptionPane.showInputDialog(newModel,
					"Please enter new Model Number: ");
			if (Models.input.contains(modelNumber)) {
				present = true;
				JOptionPane.showMessageDialog(new JFrame("error"),
						"Error: Model Number already exists!");
			} else {
				present = false;
				return modelNumber;
			}
		}
		return null;
	}
	
	public void addNew() {
		try {
			m.addNew(getNewNumber());
		} catch (FilloException e1) {
			e1.printStackTrace();
			JOptionPane.showMessageDialog(new JFrame("error"), "Could not add new Model");
		}
		fillComboBox(m.getModels());
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == addnew) {
			addNew();
		} else if (e.getSource() == next) {
			try {
				next();
			} catch (FilloException e1) {
				e1.printStackTrace();
			}
		} else if (e.getSource() == back) {
			back();
		} else if (e.getSource() == cb) {
			comboBoxUpdate();

		}
	}
}
